// js/main.js
const SCRIPT_URL = "https://script.google.com/macros/s/AKfycbzxa_rV_SLt4DPaxCiRUghHLYnGFEdhSl4q49Bk
WTaQd2lwdFV3necxMermlPWZAc1Thg/exec";

async function loadProducts() {
  try {
    const response = await fetch(`${SCRIPT_URL}?action=products`);
    const products = await response.json();

    const menuContainer = document.getElementById("menu-container");
    if (!menuContainer) return;

    menuContainer.innerHTML = "";
    products.forEach(product => {
      menuContainer.innerHTML += `
        <div class="product-card">
          <img src="${product.ImageURL}" alt="${product['Product Name']}">
          <h3>${product['Product Name']} - ${product.Variant}</h3>
          <p>₱${product.Price}</p>
          <button onclick="addToCart('${product.ProductID}','${product['Product Name']}', ${product.Price})">
            Add to Cart
          </button>
        </div>
      `;
    });
  } catch (err) {
    console.error("Failed to load products:", err);
  }
}

document.addEventListener("DOMContentLoaded", loadProducts);

