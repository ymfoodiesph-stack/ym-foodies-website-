// js/admin.js — YM Foodies Ultra live

const SCRIPT_URL = "https://script.google.com/macros/s/AKfycbzxa_rV_SLt4DPaxCiRUghHLYnGFEdhSl4q49BkWTaQd2lwdFV3necxMermlPWZAc1Thg/exec";

async function loadAdminData() {
  const table = document.getElementById("orders-table-body");
  if (!table) return;

  try {
    const response = await fetch(`${SCRIPT_URL}?action=orders`);
    const orders = await response.json();

    document.getElementById("total-orders").innerText = orders.length;
    document.getElementById("pending-orders").innerText = orders.filter(o => o.Status === "Pending").length;
    document.getElementById("revenue").innerText = `₱${orders.reduce((a, o) => a + parseFloat(o.Total || 0), 0)}`;

    table.innerHTML = "";
    orders.forEach(o => {
      table.innerHTML += `<tr>
        <td>${o.Timestamp || ''}</td>
        <td>${o.Name || ''}</td>
        <td>${o.ProductID || ''}</td>
        <td>${o.Qty || ''}</td>
        <td>₱${o.Total || 0}</td>
        <td>${o.Status || ''}</td>
      </tr>`;
    });
  } catch (err) {
    console.error("Failed to load admin data:", err);
  }
}

document.addEventListener("DOMContentLoaded", loadAdminData);

