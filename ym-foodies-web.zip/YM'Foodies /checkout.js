// js/checkout.js — YM Foodies Ultra live

const SCRIPT_URL = "https://script.google.com/macros/s/AKfycbzxa_rV_SLt4DPaxCiRUghHLYnGFEdhSl4q49BkWTaQd2lwdFV3necxMermlPWZAc1Thg/exec";

const checkoutForm = document.getElementById("checkout-form");

if (checkoutForm) {
  checkoutForm.addEventListener("submit", async e => {
    e.preventDefault();

    const customerName = document.getElementById("customerName").value;
    const contact = document.getElementById("contact").value;
    const address = document.getElementById("address").value;
    const items = JSON.parse(localStorage.getItem("ymCart")) || [];
    const total = items.reduce((a, i) => a + i.price * i.qty, 0);

    if (items.length === 0) {
      alert("Your cart is empty!");
      return;
    }

    const payload = { action: "createOrder", data: { customerName, contact, address, items, total } };

    try {
      const response = await fetch(SCRIPT_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      const result = await response.json();

      if (result.success) {
        // --- Save last order to localStorage ---
        const lastOrderData = {
          customerName,
          contact,
          address,
          items,
          total,
          orderID: result.orderID // from Apps Script
        };
        localStorage.setItem("ymLastOrder", JSON.stringify(lastOrderData));

        // --- Clear cart ---
        localStorage.removeItem("ymCart");

        // --- Redirect to order success page ---
        window.location.href = "order-success.html";
      } else {
        alert("Failed to place order. Please try again.");
      }

    } catch (err) {
      console.error("Error submitting order:", err);
      alert("Error submitting order.");
    }
  });
}