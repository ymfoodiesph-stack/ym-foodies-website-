// js/cart.js — YM Foodies Ultra

const SCRIPT_URL = "https://script.google.com/macros/s/AKfycbzxa_rV_SLt4DPaxCiRUghHLYnGFEdhSl4q49BkWTaQd2lwdFV3necxMermlPWZAc1Thg/exec";

// --- Test localStorage ---
localStorage.setItem("testKey", "Hello");
console.log("testKey:", localStorage.getItem("testKey")); // Should log "Hello"
localStorage.removeItem("testKey");
console.log("testKey after removal:", localStorage.getItem("testKey")); // Should log null

// --- Add product to cart ---
async function addToCart(id, name, price) {
  try {
    // Fetch product stock from live sheet
    const res = await fetch(`${SCRIPT_URL}?action=products`);
    const products = await res.json();
    const product = products.find(p => p.ProductID === id);

    if (!product) {
      alert("Product not found!");
      return;
    }

    let cart = JSON.parse(localStorage.getItem("ymCart")) || [];
    const existing = cart.find(item => item.id === id);

    // Stock check
    const currentQty = existing ? existing.qty + 1 : 1;
    if (currentQty > product.Stock) {
      alert(`Only ${product.Stock} left in stock`);
      return;
    }

    if (existing) existing.qty++;
    else cart.push({ id, name, price, qty: 1 });

    localStorage.setItem("ymCart", JSON.stringify(cart));
    renderCart();
    alert(`${name} added to cart`);

  } catch (err) {
    console.error("Error adding to cart:", err);
  }
}

// --- Render cart ---
function renderCart() {
  const cart = JSON.parse(localStorage.getItem("ymCart")) || [];
  const tbody = document.getElementById("cart-table-body");
  if (!tbody) return;

  tbody.innerHTML = "";
  let total = 0;

  cart.forEach(item => {
    total += item.price * item.qty;
    tbody.innerHTML += `<tr>
      <td>${item.name}</td>
      <td>₱${item.price}</td>
      <td>${item.qty}</td>
      <td>₱${item.price * item.qty}</td>
      <td><button onclick="removeCartItem('${item.id}')">Remove</button></td>
    </tr>`;
  });

  const summary = document.getElementById("cart-summary");
  if (summary) summary.innerText = `Total: ₱${total}`;
}

// --- Remove item from cart ---
function removeCartItem(id) {
  let cart = JSON.parse(localStorage.getItem("ymCart")) || [];
  cart = cart.filter(i => i.id !== id);
  localStorage.setItem("ymCart", JSON.stringify(cart));
  renderCart();
}

// --- Initialize ---
document.addEventListener("DOMContentLoaded", renderCart);