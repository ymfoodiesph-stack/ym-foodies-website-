document.addEventListener("DOMContentLoaded", () => {
  const lastOrder = JSON.parse(localStorage.getItem("ymLastOrder"));
  if (!lastOrder) return;

  const container = document.getElementById("order-details");
  if (!container) return;

  let html = `<h2>Thank you, ${lastOrder.customerName}!</h2>`;
  html += `<p>Your order has been placed successfully.</p>`;
  html += `<p><strong>Order ID: ${lastOrder.orderID || 'N/A'}</strong></p>`;
  html += `<p>Contact: ${lastOrder.contact}</p>`;
  html += `<p>Address: ${lastOrder.address}</p>`;

  html += `<table>
    <tr><th>Product</th><th>Qty</th><th>Price</th></tr>`;
  lastOrder.items.forEach(item => {
    html += `<tr>
      <td>${item.name}</td>
      <td>${item.qty}</td>
      <td>₱${item.price * item.qty}</td>
    </tr>`;
  });
  html += `</table>`;
  html += `<p><strong>Total: ₱${lastOrder.total}</strong></p>`;

  container.innerHTML = html;
});